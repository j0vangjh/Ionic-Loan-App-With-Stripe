import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { ProductService } from '../shared/services/product.service';
import { Product } from '../shared/models/product';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { positiveNumber } from '../shared/services/positiveNumber.validator';
import { FirebaseProductService } from '../shared/services/firebase-product.service';

@Component({
  selector: 'app-edit-product',
  templateUrl: './edit-product.page.html',
  styleUrls: ['./edit-product.page.scss'],
})
export class EditProductPage implements OnInit {
  productId: string;
  product: Product | undefined;
  productImage: string | undefined;
  editProductForm: FormGroup;
  categories: string[] | undefined;
  submitted: boolean = false;

  constructor(
    private route: ActivatedRoute,
    private router: Router,
    private productService: FirebaseProductService
  ) {
    this.productId = this.route.snapshot.params['id'];
    this.product = new Product('', 0, '');
    this.categories = ['Main', 'Beverage', 'Dessert'];
    this.editProductForm = new FormGroup({
      name: new FormControl(this.product?.name, [Validators.required]),
      price: new FormControl(this.product?.price, [positiveNumber]),
      category: new FormControl(this.product?.category),
      vegetarian: new FormControl(this.product?.vegetarian),
    });
    this.productService.getProductById(this.productId).subscribe((data) => {
      this.product = data;
      if (this.product) {
        this.productImage = this.product.image;
        this.editProductForm.controls['name'].setValue(this.product.name);
        this.editProductForm.controls['price'].setValue(this.product.price);
        this.editProductForm.controls['category'].setValue(
          this.product.category
        );
        this.editProductForm.controls['vegetarian'].setValue(
          this.product.vegetarian
        );
      }
    });
  }

  // eslint-disable-next-line @angular-eslint/no-empty-lifecycle-method
  ngOnInit() {}

  update() {
    this.submitted = true;
    if (this.editProductForm.valid) {
      const prod = new Product(
        this.editProductForm.value.name,
        this.editProductForm.value.price,
        this.editProductForm.value.image,
        this.productId
      ); // Use name as id
      prod.category = this.editProductForm.value.category;
      prod.vegetarian = this.editProductForm.value.vegetarian;
      this.productService.update(prod);

      this.router.navigate(['/tabs/tab2']);
    }
  }
}
